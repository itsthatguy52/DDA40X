// JavaScript for your multi-page website

// Function to handle navigation to unit pages
function navigateToUnit(unitPage) {
  window.location.href = unitPage;
}

// Function to highlight the active tab based on the current URL
function highlightActiveTab() {
  // Get the current URL
  const currentUrl = window.location.href;

  // Check if the URL contains a unit page
  if (currentUrl.includes("unit6901.html")) {
    // Set "Unit 6901" as the active tab
    document.querySelector('a[href="#unit6901"]').classList.add("active");
  } else if (currentUrl.includes("unit6902.html")) {
    // Set "Unit 6902" as the active tab
    document.querySelector('a[href="#unit6902"]').classList.add("active");
  }
  // Add more conditions for other unit pages as needed
}

// Call the function to highlight the active tab
highlightActiveTab();
